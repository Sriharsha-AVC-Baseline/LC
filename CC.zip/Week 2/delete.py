

user_list = [[id1,name1],[id2,name2]]


for user in user_list :
    response = client.delete_user(user[1],user[2])
    



response = client.delete_user(
    ServerId='string',
    UserName='string'
)