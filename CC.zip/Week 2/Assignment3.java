public class CustomerSearch {

    // Search customer by Country
    public List < Customer > SearchByCountry(string country)
    {

        var query = from customers in db.customers where customers.Country.Contains(country) orderby customers.CustomerID ascending select customers;


return query.ToList();

}

    // Search customer by companyname

public
List < Customer > SearchByCompanyName(string
company)
{

var query = from customer in db.customers where customer.Country.Contains(company) orderby customer.CustomerID ascending select customer;

return query.ToList();

}

    // Search customer by contact person

public
List < Customer > SearchByContact(string contact)
{

var query = from customer in db.customers where customer.Country.Contains(contact) orderby customer.CustomerID ascending select customer;

return query.ToList();

}

public string ExportToCSV(List < Customer > data)
{

StringBuilder
stringBuilder = new StringBuilder();

foreach(var item in data)
{
    stringBuilder.AppendFormat("{0},{1}, {2}, {3}", item.CustomerID, item.CompanyName, item.ContactName, item.Country);
    stringBuilder.AppendLine();
}

return stringBuilder.ToString();

}

}
