import random


def verify_number(number):
    if number.isdigit() and 1<= int(number) <=100:
        return True
    else:
        return False

def guess_the_number():
    generated_number=random.randint(1,100)
    number_of_guess=0
    is_right_guess=False
    print("Guess a number between 1 and 100: ")
    while not is_right_guess:
        guess=input()
        if not verify_number(guess):
            guess=input("I wont count this one Please enter a number between 1 to 100")
            continue
        else:
            number_of_guess+=1
            guess=int(guess)
            if verify_guess(guess,generated_number) is True:
               print("You guessed it in",number_of_guess,"guesses!")
               is_right_guess=True
            
                
            
            
def verify_guess(guess,generated_number):
    is_guess_right = False
    if guess<generated_number:
            print("Too low. Guess again")
            
    elif guess>generated_number:
            print("Too High. Guess again")
    
    elif guess == generated_number:
        is_guess_right = True
        
    return is_guess_right
    
    
def main():
    guess_the_number()
    
main()