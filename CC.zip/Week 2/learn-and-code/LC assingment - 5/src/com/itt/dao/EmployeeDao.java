package com.itt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.itt.connectivity.Connect;
import com.itt.entity.Employee;
import com.itt.queries.SqlQueries;

public class EmployeeDao {

	
	Connection connection;
	int rowsAffected;
	
	public EmployeeDao() throws Exception {
		this.connection = Connect.getConnection();
	}
	
	
	
	public int saveEmployeeToDatabase(Employee employee) throws Exception
	{
		
		
		PreparedStatement insertEmployeeStatement = connection.prepareStatement(SqlQueries.INSERT_STATEMENT);
		insertEmployeeStatement.setInt(1, employee.getId());
		insertEmployeeStatement.setString(2, employee.getName());
		insertEmployeeStatement.setString(3, employee.getDepartment());
		insertEmployeeStatement.setBoolean(4, employee.isWorking());
		rowsAffected = insertEmployeeStatement.executeUpdate();
		
		return rowsAffected;
	}
	
	public int deleteEmployee(Employee employee) throws Exception
	{
		PreparedStatement deleteEmployeeStatement = connection.prepareStatement(SqlQueries.DELETE_STATEMENT);
		deleteEmployeeStatement.setInt(1, employee.getId());
		rowsAffected = deleteEmployeeStatement.executeUpdate();
		
		return rowsAffected;
		
	}
	
	public List<Employee> fetchAllEmployees() throws Exception
	{
		Statement getEmployeeStatement = connection.createStatement();
		
		ResultSet employeeResultSet = getEmployeeStatement.executeQuery(SqlQueries.FETCH_STATEMENT);
		
		List<Employee> employeeList = convertResultSetToList(employeeResultSet);
		
		return employeeList;
		
	}
	
	public List<Employee> convertResultSetToList(ResultSet employeeResultSet) throws Exception
	{
		List<Employee> employees = new ArrayList<Employee>();
		
		Employee temporaryEmployee = null;
		
		while(employeeResultSet.next())
		{
			temporaryEmployee = new Employee();
			temporaryEmployee.setId(employeeResultSet.getInt(1));
			temporaryEmployee.setName(employeeResultSet.getString(2));
			temporaryEmployee.setDepartment(employeeResultSet.getString(3));
			temporaryEmployee.setWorking(employeeResultSet.getBoolean(4));
			
			employees.add(temporaryEmployee);
			
		}
		
		return employees;
	}
	
	
	
}
