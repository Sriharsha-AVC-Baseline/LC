package com.itt.service;

import java.sql.Connection;
import javax.sql.*;
import com.itt.connectivity.Connect;
import com.itt.dao.EmployeeDao;
import com.itt.entity.Employee;

public class Main {
	
	public static void main(String[] args) throws Exception {
		
	EmployeeDao employeeDao = new EmployeeDao();
	
	Employee employee = new Employee();
	employee.setId(3);
	employee.setName("Mohan");
	employee.setDepartment("HR");
	employee.setWorking(true);
	
		try {
	
	//employeeDao.saveEmployeeToDatabase(employee);
	
	//employeeDao.deleteEmployee(employee);
			
		}
		catch(Exception exception)
		{
			System.out.println("Some Error Occured");
		}
	
	PrintService service = new PrintService();
	
	service.printEmployeesInCSV(employeeDao.fetchAllEmployees());
	
	service.printEmployeesInXML(employeeDao.fetchAllEmployees());
	
	WorkValidator validator = new WorkValidator();
	
	validator.checkIsEmployeeWorking(employee);
	
	
	
	}
}
