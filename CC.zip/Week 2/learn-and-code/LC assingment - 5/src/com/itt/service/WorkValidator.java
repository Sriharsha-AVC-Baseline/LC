package com.itt.service;

import com.itt.entity.Employee;

public class WorkValidator {

	
	public void checkIsEmployeeWorking(Employee employee)
	{
		if(employee.isWorking())
		{
			System.out.println("Employee is Working");
		}
		else
		{
			System.out.println("Not Working");
		}
	}
}
