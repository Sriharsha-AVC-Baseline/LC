package com.itt.service;

import java.io.StringWriter;
import com.fasterxml.jackson.dataformat.xml.*;
import java.util.List;
import javax.xml.bind.*;

import com.itt.entity.Employee;
import com.itt.entity.EmployeeList;

public class PrintService {
	
	
	public void printEmployeesInCSV(List<Employee> employeeList)
	{	
		
		for (Employee employee : employeeList) {
			System.out.print("\""+employee.getId()+"\", ");
			System.out.print("\""+employee.getName()+"\", ");
			System.out.print("\""+employee.getDepartment()+"\", ");
			System.out.print("\""+employee.isWorking()+"\"\n");
		}
	}

	public void printEmployeesInXML(List<Employee> employeeList)
	{
		EmployeeList employees = new EmployeeList();
		employees.setEmployeeList(employeeList);
		System.out.println( employeeToXML(employees));
	}
	
	public String employeeToXML(EmployeeList employee) 
	{
		 String xmlContent = null;
	    try 
	    {
	        JAXBContext jaxbContext = JAXBContext.newInstance(EmployeeList.class,Employee.class);
	        
	        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

	        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

	        StringWriter stringWriter = new StringWriter();
	        
	        jaxbMarshaller.marshal(employee, stringWriter);
	        
	        xmlContent = stringWriter.toString();
	        
	        return xmlContent;

	    } catch (JAXBException e) {
	        e.printStackTrace();
	    }
		return xmlContent;
	}
}
