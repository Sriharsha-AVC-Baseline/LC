package com.itt.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {
	
	private static String username;
	
	private static String password;
	
	private static String url;
	
	private static Connection connection = null;
	
	
	private Connect() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		username = (String)System.getenv("Db_UserName");
		password = (String)System.getenv("password");
		connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/dummy?allowPublicKeyRetrieval=true&useSSL=false",username,password);
	}
	
	public static Connection getConnection() throws Exception
	{
		if(connection==null)
		{
			Connect connect = new Connect(); 
			System.out.println("New Connection invoked");
		}
		
		return connection;
	}
	
	

}
