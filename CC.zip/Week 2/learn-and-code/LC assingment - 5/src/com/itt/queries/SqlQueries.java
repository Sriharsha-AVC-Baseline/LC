package com.itt.queries;

public class SqlQueries {
	
	public static final String INSERT_STATEMENT = "INSERT INTO EMPLOYEE VALUES(?,?,?,?)";
	
	public static final String DELETE_STATEMENT = "DELETE FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
	
	public static final String FETCH_STATEMENT = "SELECT * FROM EMPLOYEE";

}
