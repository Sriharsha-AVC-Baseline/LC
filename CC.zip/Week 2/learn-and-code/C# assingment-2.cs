using System;
using System.Numerics;
class MyClass {

/*
You are given an array of n numbers and q queries. For each query you have to print the floor of the expected value(mean) of the subarray from L to R.
Inputs
First line contains two integers N and Q denoting number of array elements and number of queries.
Next line contains N space seperated integers denoting array elements.
Next Q lines contain two integers L and R(indices of the array).
Output
print a single integer denoting the answer.
*/

    static void Main(string[] args) {
       var keyboardInputs = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);
            var array = Array.ConvertAll(Console.ReadLine().Split(' '), long.Parse);
            var numberOfElements = keyboardInputs[0];
            var numberOfQueries = keyboardInputs[1];

            long[] sumOfArrayElements = getSumOfArray(array,numberOfElements);

            for (var index = 0; index < numberOfQueries; index++)
            {
                var indicesOfArray = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse)
                var answer = processQueries(sumOfArrayElements,indicesOfArray);
                printOutput(answer);
            }       
    }

    static long[] getSumOfArray(long[] array,long numberOfElements)
    {
        long[] sumOfArrayElements = new long[numberOfElements + 1];
            sumOfArrayElements[0] = calculateSumOfArray(array,sumOfArrayElements,numberOfElements);
            return sumOfArrayElements;
    }

    static long[] calculateSumOfArray(long[] array,long[] sumOfArrayElements,long numberOfElements)
    {
        sumOfArrayElements[0] = 0;
            for (int index = 1; index <= numberOfElements; index++)
            {
                sumOfArrayElements[index] = addTwoNumbers(sumOfArrayElements[index - 1],array[index - 1]);
            }
            return sumOfArrayElements;
    }

    static long addTwoNumbers(long element1,long element2)
    {
        return element1 + element2;
    }

    static long processQueries(long numberOfQueries,long[] sumOfArrayElements,long[] indicesOfArray)
    {
        var rightIndex = indicesOfArray[0];
        var leftIndex = indicesOfArray[1];
        return (long)((long)(sumOfArrayElements[left] - sumOfArrayElements[right] - 1) / (left - right + 1));
    }

    static void printOutput(var answer)
    {
         Console.WriteLine(answer);
           
    }


}