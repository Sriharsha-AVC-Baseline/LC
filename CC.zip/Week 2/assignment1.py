def verify_number(number):
    if number.isdigit() and 1<= int(number) <=100:
        return True
    else:
        return False
    
def check_the_guess(guess,generated_number):
    number_of_guess=0
    is_right_guess=False
    while not is_right_guess:
        if not verify_number(guess):
            guess=input("I wont count this one Please enter a number between 1 to 100")
            continue
        else:
            number_of_guess+=1
            guess=int(guess)
        if guess<generated_number:
            guess=input("Too low. Guess again")
        elif guess>generated_number:
            guess=input("Too High. Guess again")
        else:
            print("You guessed it in",number_of_guesses,"guesses!")
            is_right_guess=True

def main():
    generated_number=random.randint(1,100)
    guess=input("Guess a number between 1 and 100:")
    check_the_guess(guess,generated_number)
    
