package com.itt.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.List;

import com.itt.connect.DBOperator;
import com.itt.entity.EmployeeEntity;

public class Application {
	
	private BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	
	private DBOperator dbOperator = new DBOperator();
	
	public void startApp() throws Exception
	{
		int choice = 0;
		
		
		
		while(choice != 3)
		{
			
			System.out.println("Enter the Choice\n1.Add Employee\n2.Fetch Employee\n3.Exit");
			choice = Integer.parseInt(bufferedReader.readLine());
			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				fetchEmployee();
			case 3:
				return;
			default:
				System.out.println("Enter Valid Choice");;
			}
		}
		
	}

	private void fetchEmployee() throws SQLException {
		// TODO Auto-generated method stub
		
		System.out.println("Employee are :");
		
		List<EmployeeEntity> employees = dbOperator.getEmployee();
		
		employees.forEach(e->System.out.println(e));
		
	}

	private void addEmployee() throws Exception {
		// TODO Auto-generated method stub
		
		dbOperator.addEmployee(readDetails());
	}
	
	private EmployeeEntity readDetails() throws Exception
	{
		
		int id;
		String employeeName;
		String employeeDepartment;
		
		System.out.print("Employee ID : ");
		id = Integer.parseInt(bufferedReader.readLine());
		System.out.print("Employee name : ");
		employeeName = bufferedReader.readLine();
		System.out.print("Employee Department : ");
		employeeDepartment = bufferedReader.readLine();
		
		EmployeeEntity employeeEntity = new EmployeeEntity(id, employeeName, employeeDepartment);
		return employeeEntity;
	}
	

}
