package com.itt.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.itt.entity.EmployeeEntity;

public class Main {
	public static void main(String[] args) throws Exception {
		
		Application application = new Application();
		application.startApp();
		
	}
}
