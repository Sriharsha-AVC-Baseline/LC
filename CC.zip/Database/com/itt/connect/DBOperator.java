package com.itt.connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.itt.entity.EmployeeEntity;

public class DBOperator {
	
	private Connection connection;

	public DBOperator()
	{
		this.connection = Connect.getInstance();
	}
	
	public void addEmployee(EmployeeEntity employee) throws Exception
	{
		if(employee == null)
		{
			throw new Exception("Employee field is null");
		}
		else
		{
			insertEmployee(employee);
			
			System.out.println("Employee added successfully");
		}
	}
	
	
	public List<EmployeeEntity> getEmployee() throws SQLException
	{
		List<EmployeeEntity> employeeList = getFetchEmployees();
		
		return employeeList;
		
	}
	
	private List<EmployeeEntity> getFetchEmployees() throws SQLException {
		
		List<EmployeeEntity> employeeList = new ArrayList<>();
		
		Statement fetchStatement = connection.createStatement();
		
		ResultSet employeeResultSet = fetchStatement.executeQuery("SELECT * FROM EMPLOYEE");
		
		while(employeeResultSet.next())
		{
			employeeList.add(new EmployeeEntity(employeeResultSet.getInt(1), employeeResultSet.getString(2), employeeResultSet.getString(3)));
		}
		
		return employeeList;
		
	}

	private void insertEmployee(EmployeeEntity employee) throws SQLException
	{

		PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO EMPLOYEE VALUES(?,?,?)");
		
		preparedStatement.setInt(1, employee.getEmployeeId());
		preparedStatement.setString(2, employee.getEmployeeName());
		preparedStatement.setString(3, employee.getEmployeeDepartment());
		preparedStatement.executeUpdate();
	}
	
	
	
}
