package com.itt.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
	
	private static Connection connection;
	
	private static Connect connect = null;
	
	private Connect() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String username = (String)System.getenv("Db_UserName");
			String password = (String)System.getenv("password");
			connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/dummy?allowPublicKeyRetrieval=true&useSSL=false",username,password);
		}
		catch(Exception e)
		{
			connection = null;
		}
		
	}
	
	public static Connection getInstance()
	{
		if(connect == null)
		{
			connect = new Connect();
		}
		return connect.connection;
	}
	
	

}
