import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.itt.main.FactorsFinder;

class PositiveScenarios {

	private FactorsFinder factorsFinder;

	@BeforeEach
	void setUp() {
		factorsFinder = new FactorsFinder();
	}

	@Test
	void numberSingleDigitThree() {
		assertEquals(1, factorsFinder.getNumberOfFactors(3));
	}

	@Test
	void numberfifteen() {
		assertEquals(2, factorsFinder.getNumberOfFactors(15));
	}

	@Test
	void numberHundred() {
		assertEquals(15, factorsFinder.getNumberOfFactors(100));
	}

	@Test
	void numberThirtyFive() {
		assertEquals(6, factorsFinder.getNumberOfFactors(35));
	}

}
