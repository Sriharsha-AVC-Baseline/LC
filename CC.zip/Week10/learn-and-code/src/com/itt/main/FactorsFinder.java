package com.itt.main;

public class FactorsFinder {

	class Pair {
		int countOfOne, countOfTwo;
		int num1,num2;
	}

	public int getNumberOfFactors(int number) {
		int count = 0;
		for (int iterator = 1; iterator < number; iterator++) {
			Pair pair = getFactorsOfPairs(iterator);
			if (pair.countOfOne == pair.countOfTwo) {
				count++;
			}
		}

		return count;
	}

	private Pair getFactorsOfPairs(int number) {
		Pair pair = new Pair();
		pair.countOfOne = 1;
		pair.countOfTwo = 1;
		int number1 = number;
		int number2 = number + 1;
		pair.num1 = number1;
		pair.num2 = number2;
		for (int iterator = 1; iterator < (number2 / 2) + 1; iterator++) {
			if (number1 % iterator == 0 && number1 > iterator) {
				pair.countOfOne++;
			}
			if (number2 % iterator == 0) {
				pair.countOfTwo++;
			}
		}

		return pair;
	}

}
