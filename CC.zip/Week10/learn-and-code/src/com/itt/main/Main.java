package com.itt.main;

public class Main {

	public static void main(String[] args) {
		
		Application application = new Application();
		application.startApp();

	}

}
