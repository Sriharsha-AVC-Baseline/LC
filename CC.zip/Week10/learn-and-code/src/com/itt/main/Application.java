package com.itt.main;

import java.util.Scanner;

public class Application {
	private int testCases;
	private int[] numbers;
	private FactorsFinder finder = new FactorsFinder();

	public void startApp() {
		testCases = scanNumber();

		numbers = new int[testCases];
		for (int iterator = 0; iterator < testCases; iterator++) {
			numbers[iterator] = scanNumber();
			printNumberOfFactors(numbers[iterator]);
		}
	}

	private int scanNumber() {
		Scanner scan = new Scanner(System.in);
		return scan.nextInt();
	}

	private void printNumberOfFactors(int number) {
		System.out.println(finder.getNumberOfFactors(number));
	}
}
