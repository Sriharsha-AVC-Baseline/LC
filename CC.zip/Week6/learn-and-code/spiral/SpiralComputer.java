package spiral;

public class SpiralComputer {

	private int constantNumber;
	private int signFactor;
	private int result;
	
	
	public int calculateSpiralNumber(CoordinatesData coordinatesData) {

		constantNumber = getLargestAbsoluteCoordinate(coordinatesData);
		 signFactor = getSignFactor(coordinatesData);

		result = computeFinalResult(coordinatesData);
		
		

		return result;
	}
	
	
	private int computeFinalResult(CoordinatesData coordinatesData)
	{
		int result = (4 * constantNumber * constantNumber);
		result = result + signFactor * (2 * constantNumber - getSum(coordinatesData));
		
		result = result + coordinatesData.getStartNumber();
		return result;
	}
	
	private int getSum(CoordinatesData coordinatesData)
	{
		return (coordinatesData.leftIndex + coordinatesData.rightIndex);
	}

	private int getLargestAbsoluteCoordinate(CoordinatesData coordinatesData) {
		return (int) (Math.max(Math.abs(coordinatesData.leftIndex), Math.abs(coordinatesData.rightIndex)));
	}

	
	
	private int getSignFactor(CoordinatesData coordinatesData) {
		int signFactor = 1;

		if (coordinatesData.rightIndex > coordinatesData.leftIndex) {
			signFactor = -1;
		}

		return signFactor;
	}
}
