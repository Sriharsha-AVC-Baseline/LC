package spiral;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputReader {
	
	public CoordinatesData initializeDetails() {

		CoordinatesData coordinatesData = null;

		try {
			coordinatesData = readDetails();
		}
		
		catch (Exception exception) {
			System.out.println("Invalid number");
			coordinatesData = initializeDetails();
		}

		return coordinatesData;
	}
	

	
	private CoordinatesData readDetails() throws NumberFormatException, IOException {

		Coordinates coordinates = new Coordinates();

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter left index");

		coordinates.setLeftIndex(Integer.parseInt(reader.readLine()));

		System.out.println("Enter the right index");

		coordinates.setRightIndex(Integer.parseInt(reader.readLine()));

		System.out.println("The spiral should be rotating in\n"
				+ "1.Clockwise (Default)\n"
				+ "2.Anticlockwise\n"
				+ "3.Clockwise Bottom\n"
				+ "4.Anticlockwise Bottom\n"
				+ "5.Anticlockwise Right\n"
				+ "6.Clockwise Right\n"
				+ "7.Clockwise Left\n"
				+ "8.Anticlockwise Left\n");
		
		int index = Integer.parseInt(reader.readLine());
		
		index--;
		
		Directions[] allDirections = getAllDirections();
		
		coordinates.setDirection(allDirections[index]);
		
		System.out.println("Enter the starting number");
		
		coordinates.setStartNumber(Integer.parseInt(reader.readLine()));
		
		System.out.println("Enter Starting left index");

		coordinates.setStartLeftIndex(Integer.parseInt(reader.readLine()));

		System.out.println("Enter Starting the right index");

		coordinates.setStartRightIndex(Integer.parseInt(reader.readLine()));
		
		coordinates.setIndexAccordingToDirection();
		
		coordinates.setStartingCoordinates();
		
		return coordinates;
	}



	private Directions[] getAllDirections() {
		// TODO Auto-generated method stub
		return Directions.values();
	}
	
	
}
