package spiral;

public class CoordinatesData {

	protected int leftIndex;
	protected int rightIndex;
	
	protected Directions direction;
	protected int startNumber;
	
	protected int startLeftIndex;
	protected int startRightIndex;
	
	public int getStartLeftIndex() {
		return startLeftIndex;
	}

	public void setStartLeftIndex(int startLeftIndex) {
		this.startLeftIndex = startLeftIndex;
	}

	public int getStartRightIndex() {
		return startRightIndex;
	}

	public void setStartRightIndex(int startRightIndex) {
		this.startRightIndex = startRightIndex;
	}

	public int getStartNumber() {
		return startNumber;
	}

	public void setStartNumber(int startNumber) {
		this.startNumber = startNumber;
	}

	public int getLeftIndex() {
		return leftIndex;
	}

	public void setLeftIndex(int leftIndex) {
		this.leftIndex = leftIndex;
	}

	public int getRightIndex() {
		return rightIndex;
	}

	public void setRightIndex(int rightIndex) {
		this.rightIndex = rightIndex;
	}

	public Directions getDirection() {
		return direction;
	}

	public void setDirection(Directions direction) {
		this.direction = direction;
	}


}
