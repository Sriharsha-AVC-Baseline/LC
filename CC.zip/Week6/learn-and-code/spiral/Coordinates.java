package spiral;

public class Coordinates extends CoordinatesData {
	
	public Coordinates() {
		direction = Directions.CLOCKWISE_TOP;
		
		startLeftIndex = 0;
		startRightIndex = 0;
	}
	
	public void setStartingCoordinates()
	{
		leftIndex = leftIndex + startLeftIndex;
		rightIndex = rightIndex + startRightIndex;
	}
	
	
	public void setIndexAccordingToDirection()
	{
		
		switch (direction) {
		
		case ANTICLOCKWISE_TOP:
			getAnticlockwiseTop();
			break;
			
		case CLOCKWISE_BOTTOM:
			getClockwiseBottom();
			break;
			
		case ANTICLOCKWISE_BOTTOM:
			getAntiClockwiseBottom();
			break;
			
		case ANTICLOCKWISE_RIGHT:
			getAnticlockwiseRight();
			break;
			
		case CLOCKWISE_RIGHT:
			getClockwiseRight();
			break;
			
		case CLOCKWISE_LEFT:
			getClockwiseLeft();
			break;
			
		case ANTICLOCKWISE_LEFT:
			getAnticlockwiseLeft();
			break;
			
		default:
			break;
		}
		
	}
	
	
	private void getAntiClockwiseBottom() {
		inverseLeftIndex();
	}

	private void getClockwiseBottom() {
		inverseLeftIndex();
		inverseRightIndex();
	}

	private void getAnticlockwiseTop()
	{
		inverseRightIndex();
	}
	
	
	
	private void inverseRightIndex()
	{
		rightIndex = rightIndex * -1;
	}
	
	private void inverseLeftIndex()
	{
		leftIndex = leftIndex * -1;
	}
	
	
	private void getAnticlockwiseRight()
	{
		if(checkAnyOneIndexIsNegative()==false)
		{
			inverseLeftIndex();
			inverseRightIndex();
			inverseIndex();
		}
	}
	
	private void getClockwiseRight()
	{
		getAnticlockwiseRight();
		inverseRightIndex();
	}
	
	private void getClockwiseLeft() {
		
		getAnticlockwiseRight();
		inverseLeftIndex();
	}
	
	private void getAnticlockwiseLeft() {
		// TODO Auto-generated method stub
		getClockwiseLeft();
		inverseRightIndex();
		
	}
	
	private boolean checkAnyOneIndexIsNegative() {
		boolean anyOneIsNegative = false;
		
		if(leftIndex <= 0)
		{
			anyOneIsNegative = true;
		}
		
		if(rightIndex <= 0)
		{
			if(anyOneIsNegative == false)
			{
				anyOneIsNegative = true;
			}
			else
			{
				anyOneIsNegative = false;
			}
		}
		
		return anyOneIsNegative;
	}

	private void inverseIndex()
	{
		int temporary = leftIndex;
		leftIndex = rightIndex;
		rightIndex = temporary;
	}

}
