#include<iostream>
using namespace std;

int main()
{
    int size_of_spiral;

    cin>>size_of_spiral;

    int matrix[size_of_spiral][size_of_spiral];

    int number = (size_of_spiral * size_of_spiral) - 1;

    int i=0,j,k,l,m;
    int start_index = 0;
    int end_index = size_of_spiral - 1;

    while(number >= 0)
    {
        
       for(i = start_index; i <= end_index; i++)
       {
            matrix[i][start_index] = number;
            number--;
       }

       for(i = start_index+1; i <= end_index; i++)
        {
            matrix[end_index][i] = number;
            number--;
        }
        cout<<number<<"\n"<<endl;
        for(i = end_index-1; i >= start_index; i--)
        {
            matrix[i][end_index] = number;
            number--;
        }
    
        end_index--;
        
          for(i = end_index; i >= start_index+1; i--)
        {
            matrix[start_index][i] = number;
            number--;
        }
        start_index++;
      //  break;
    }
    for(int i=0;i<size_of_spiral;i++)
    {
        for(int j=0;j<size_of_spiral;j++)
        {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}