package sprial;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Coordinates {
	public int leftIndex;
	public int rightIndex;
}

public class Spiral {

	public static void main(String[] args) {

		Coordinates coordinates = initializeDetails();

		int result = calculateSpiralNumber(coordinates);

		System.out.println("Result is " + result);
	}

	// Vertical openness for separating functionality
	public static int calculateSpiralNumber(Coordinates coordinates) {

		int constantNumber = getLargestAbsoluteCoordinate(coordinates);
		int signFactor = getSignFactor(coordinates);

		int result = (4 * constantNumber * constantNumber);
		result = result + signFactor * (2 * constantNumber - getSum(coordinates));

		return result;
	}

	public static int getSum(Coordinates coordinates) {
		return (coordinates.leftIndex + coordinates.rightIndex);
	}

	public static int getLargestAbsoluteCoordinate(Coordinates coordinates) {
		return (int) (Math.max(Math.abs(coordinates.leftIndex), Math.abs(coordinates.rightIndex)));
	}

	public static int getSignFactor(Coordinates coordinates) {
		int signFactor = 1;

		if (coordinates.rightIndex > coordinates.leftIndex) {
			signFactor = -1;
		}

		return signFactor;
	}

	public static Coordinates initializeDetails() {

		Coordinates coordinates = null;

		try {
			coordinates = readDetails();
		}

		catch (Exception exception) {
			System.out.println("Invalid number");
			coordinates = initializeDetails();
		}

		return coordinates;
	}

	public static Coordinates readDetails() throws NumberFormatException, IOException {

		Coordinates coordinates = new Coordinates();

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter left index");

		coordinates.leftIndex = Integer.parseInt(reader.readLine());

		System.out.println("Enter the right index");

		coordinates.rightIndex = Integer.parseInt(reader.readLine());

		return coordinates;
	}

}
