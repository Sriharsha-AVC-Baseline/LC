import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Assignment1 {

    public static String[] countryCodes = { "AUS", "BGD", "CHN", "EGY", "IND", "NLD", "ZAF", "CHE", "USA", "RUS" };
    public static String[] countryNames = { "Australia", "Bangladesh", "China", "Egypt", "India", "Netherlands",
            "South Africa", "Switzerland", "United States", "Russia", };

    public static void main(String[] args) throws IOException {

        System.out.println("Enter your Country code Please");
        // BufferedReader bufferedReader = new BufferedReader(new
        // InputStreamReader(System.in));
        String countryCode = "AUS";// bufferedReader.readLine();

        Scanner scan = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            System.out.println(scan.nextLine());
        }

        System.out.println("Name of the country is " + getCountryName(countryCode));

    }

    public static String getCountryName(String code) {

        for (int i = 0; i < countryCodes.length; i++) {
            if (countryCodes[i].equalsIgnoreCase(code)) {
                return countryNames[i];
            }
        }

        return "Unknown country code";

    }
}