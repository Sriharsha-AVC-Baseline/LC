
public class Match {

	private String homeTeam;

	private String oponentTeam;

	public String getHomeTeam() {
		return homeTeam;
	}

	public void setHomeTeam(String homeTeam) {
		this.homeTeam = homeTeam;
	}

	public String getOponentTeam() {
		return oponentTeam;
	}

	public void setOponentTeam(String oponentTeam) {
		this.oponentTeam = oponentTeam;
	}

	@Override
	public String toString() {
		return this.homeTeam + " vs " + this.oponentTeam;
	}

}
