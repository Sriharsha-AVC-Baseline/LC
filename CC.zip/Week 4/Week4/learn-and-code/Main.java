
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static List<Match> matches = new LinkedList<>();

	public static List<String> teams = new ArrayList<String>();

	public static int numberOfTeams, numberOfMatches = 0;

	public static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws NumberFormatException, IOException {

		readDetails();

		matches = MatchScheduler.computeTotalMatches(teams);

		List<Match> scheduledMatchPlan = MatchScheduler.scheduleMatch(matches, numberOfTeams);

		printScheduledMatches(scheduledMatchPlan);
	}

	public static void readDetails() {

		try {
			scanDetails();
		}

		catch (NumberFormatException | IOException exception) {
			System.out.println("Invalid Details");
			readDetails();
		}

	}

	public static void printScheduledMatches(List<Match> scheduledMatches) {
		int day = 1;
		int numberOfMatch = 0;
		System.out.println("\nScheduled Matches\n");
		for (Match match : scheduledMatches) {
			if (match.toString().equalsIgnoreCase("- vs -")) {
				System.out.println(day + " day : No match on this day");
				day++;
				continue;

			}

			System.out.println(day + " day : " + match.toString());
			day++;
			numberOfMatch++;
		}

		System.out.println("Total matches are : " + numberOfMatch);

	}

	public static void scanDetails() throws NumberFormatException, IOException {
		System.out.print("Enter the number of Teams : ");
		numberOfTeams = Integer.parseInt(bufferedReader.readLine());
		System.out.println("Enter teams : ");
		for (int iterator = 0; iterator < numberOfTeams; iterator++) {
			teams.add(bufferedReader.readLine());
		}
	}

}
