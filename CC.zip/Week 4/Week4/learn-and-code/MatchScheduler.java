

import java.util.LinkedList;
import java.util.List;

public class MatchScheduler {

	public static List<Match> computeTotalMatches(List<String> teams) {

		int numberOfTeams = teams.size();

		List<Match> totalMatches = new LinkedList<Match>();

		for (int homeTeamIndex = 0; homeTeamIndex < numberOfTeams; homeTeamIndex++) {
			for (int oponentTeamIndex = homeTeamIndex; oponentTeamIndex < numberOfTeams; oponentTeamIndex++) {
				if (homeTeamIndex == oponentTeamIndex) {
					continue;
				}

				String homeTeam = teams.get(homeTeamIndex);
				String oponentTeam = teams.get(oponentTeamIndex);

				Match newMatch = new Match();
				newMatch.setHomeTeam(homeTeam);
				newMatch.setOponentTeam(oponentTeam);

				Match reMatch = new Match();
				reMatch.setOponentTeam(homeTeam);
				reMatch.setHomeTeam(oponentTeam);

				totalMatches.add(newMatch);
				totalMatches.add(reMatch);

			}

		}
		return totalMatches;

	}

	public static List<Match> scheduleMatch(List<Match> matches, int teams) {
		List<Match> matchSchedule = new LinkedList<>();

		List<String> recentlyPlayedTeams = new LinkedList<>();

		int numberOfNoMathDay = 0;

		int matchListIndex = 0;

		while (matches.isEmpty() == false) {

			if (matchListIndex >= matches.size()) {
				matchListIndex = 0;

				Match noMatch = setNoMatch();
				numberOfNoMathDay++;

				Match lastMatch = matchSchedule.get(matchSchedule.size() - 1);
				if (numberOfNoMathDay <= 1 && recentlyPlayedTeams.size() <= 2
						&& checkRecentMatches(recentlyPlayedTeams, lastMatch)) {
					matchSchedule.add(noMatch); // This will add another day gap if two teams already played a match
				}

				matchSchedule.add(noMatch);

				recentlyPlayedTeams = removeFirstDayMatch(recentlyPlayedTeams);
			}

			Match match = matches.get(matchListIndex);

			if (checkRecentMatches(recentlyPlayedTeams, match) == false) {

				matchSchedule.add(matches.get(matchListIndex));

				if (checkWhetherMatchHappenedFromPastTwoDays(recentlyPlayedTeams)) {
					recentlyPlayedTeams = removeFirstDayMatch(recentlyPlayedTeams);
				}

				recentlyPlayedTeams = updateRecentlyPlayedMatches(recentlyPlayedTeams, matches.get(matchListIndex));

				matches.remove(matchListIndex);

				numberOfNoMathDay = 0;

			}

			matchListIndex++;

		}

		return matchSchedule;
	}

	public static List<String> updateRecentlyPlayedMatches(List<String> recentlyPlayedTeams, Match match) {
		recentlyPlayedTeams.add(match.getHomeTeam());
		recentlyPlayedTeams.add(match.getOponentTeam());
		return recentlyPlayedTeams;
	}

	public static List<String> removeFirstDayMatch(List<String> recentlyPlayedTeams) {
		recentlyPlayedTeams.remove(0);
		recentlyPlayedTeams.remove(0);
		return recentlyPlayedTeams;
	}

	public static boolean checkWhetherMatchHappenedFromPastTwoDays(List<String> recentlyPlayedTeams) {
		boolean result = false;
		if (recentlyPlayedTeams.size() >= 4) {
			result = true;
		}
		return result;
	}

	public static boolean checkRecentMatches(List<String> recentlyPlayed, Match match) {
		boolean playedRecentMatches = false;

		for (String team : recentlyPlayed) {
			if (team.equals(match.getHomeTeam()) || team.equals(match.getOponentTeam())) {
				playedRecentMatches = true;
				break;
			}
		}
		return playedRecentMatches;
	}

	public static Match setNoMatch() {
		Match noMatch = new Match();
		noMatch.setHomeTeam("-");
		noMatch.setOponentTeam("-");
		return noMatch;
	}
}
