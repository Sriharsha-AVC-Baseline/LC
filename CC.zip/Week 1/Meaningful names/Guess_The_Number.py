def valid_number(number):
    if number.isdigit() and 1<= int(number) <=100:
        return True
    else:
        return False

def main():
    number_generated=random.randint(1,100)
    correct_guess=False
    guess=input("Guess a number between 1 and 100:")
    number_of_guesses=0
    while not correct_guess:
        if not valid_number(guess):
            guess=input("I wont count this one Please enter a number between 1 to 100")
            continue
        else:
            number_of_guesses+=1
            guess=int(guess)

        if guess<number_generated:
            guess=input("Too low. Guess again")
        elif guess>number_generated:
            guess=input("Too High. Guess again")
        else:
            print("You guessed it in",number_of_guesses,"guesses!")
            correct_guess=True


