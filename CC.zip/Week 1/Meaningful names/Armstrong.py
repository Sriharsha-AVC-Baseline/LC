def check_armstrong(number):
    # Initializing Sum and Number of Digits
    sum_of_digits = 0
    number_of_digits = 0

    # Calculating Number of individual digits
    temporary = number
    while temporary > 0:
        number_of_digits = number_of_digits + 1
        temporary = temporary // 10

    # Finding Armstrong Number
    temporary = number
    for n in range(1, temporary + 1):
        remainder = temporary % 10
        sum_of_digits = sum_of_digits + (remainder ** number_of_digits)
        temporary //= 10
    return sum_of_digits


# End of Function

# User Input
number = int(input("\nPlease Enter the Number to Check for Armstrong: "))

if (number == check_armstrong(number)):
    print("\n %d is Armstrong Number.\n" % number)
else:
    print("\n %d is Not a Armstrong Number.\n" % number)