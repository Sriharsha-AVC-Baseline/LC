import random
def get_die_value(max_die_value):
    rolled_result=random.randint(1, s)
    return rolled_result


def main():
    max_die_value=6
    playing=True
    while playing:
        will_quit=input("Ready to roll? Enter Q to Quit")
        if will_quit.lower() !="q":
            rolled_result=get_die_value(max_die_value)
            print("You have rolled a",rolled_result)
        else:
            playing=False
