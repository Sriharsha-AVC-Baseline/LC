import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Assignment1 {

    public static String[] countryCodes = { "AUS", "BGD", "CHN", "EGY", "IND", "NLD", "ZAF", "CHE", "USA", "RUS" };
    public static String[] countryNames = { "Australia", "Bangladesh", "China", "Egypt", "India", "Netherlands",
            "South Africa", "Switzerland", "United States", "Russia", };

    public static void main(String[] args) throws IOException {

        System.out.println("Enter your Country code Please");
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        String countryCode = bufferedReader.readLine();

        System.out.println("Adjacent countries of " + countryCode + " = " + getCountryName(countryCode));

    }

    public static String getCountryName(String code) {

        for (int i = 0; i < countryCodes.length; i++) {
            if (countryCodes[i].equalsIgnoreCase(code) && i == 0) {
                return countryNames[i + 1];
            } else if (countryCodes[i].equalsIgnoreCase(code) && i == (countryCodes.length - 1)) {
                return countryNames[i - 1];
            } else if (countryCodes[i].equalsIgnoreCase(code)) {
                return countryNames[i - 1] + " and " + countryNames[i + 1];
            }
        }

        return "Unknown country code";

    }
}