#include<iostream>
#include<string.h>
using namespace std;

string codeToName(string code)
{
    string countryCodes[] = {"IND","US","NZ"};
    string countryNames[] = {"India","United States Of America","New Zealand"};

    int arrayIterator = 0;

        for(arrayIterator = 0; arrayIterator < 3; arrayIterator++)
        {
            if(countryCodes[arrayIterator] == code)
            {
                return countryNames[arrayIterator];
            }
        }
    return "None";

}

int main()
{
    cout<<"Enter the country code"<<endl;
    string code;
    cin>>code;
    cout<<codeToName(code);
}