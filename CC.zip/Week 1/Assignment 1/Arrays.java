import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

class Arrays {
    public static void main(String[] args) throws Exception {
        String[] array = new String[20];
        String[] array2 = { "A", "B" };

        Scanner scan = new Scanner(System.in);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        String name;
        int roll;
        System.out.println("Enter Roll number");
        roll = Integer.parseInt(bufferedReader.readLine());
        Integer Roll = new Integer(roll);
        System.out.println("Enter name");

        name = bufferedReader.readLine();

        System.out.println("Roll " + Roll.getClass().getName() + " name = " + name);

    }
}