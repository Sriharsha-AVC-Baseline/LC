package com.itt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DatabaseConnector {
	
	
	private static Connection connection;
	private String userName=System.getenv("Db_UserName");
	private String password=System.getenv("password");
	private String url="jdbc:mysql://localhost:3306/BankWithDraw";
	
	private DatabaseConnector()
	{
		if(connection == null)
		{
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection(url, userName, password);
				
			} catch (SQLException|ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static Connection getConnection()
	{
		if(connection == null)
		{
			new DatabaseConnector();
		}
		return connection;
	}
}
