package com.itt.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.itt.pojo.Account;

public class DBOperator {
	
	private Connection connection = DatabaseConnector.getConnection();
	
	public boolean addAccount(Account account)
	{
		boolean result = false;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?,?,?)");
			preparedStatement.setLong(1, account.getAccountNumber());
			preparedStatement.setLong(2, account.getAmount());
			preparedStatement.setShort(3, account.getPinCode());
			preparedStatement.setString(4, account.getAccountHolderName());
			preparedStatement.execute();
			result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public Account getDetails(long accountNumber)
	{
		Account account = null;
		String userName;
		long balance=0,accNumber = 0;
		short pinCode = (short)0;
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM ACCOUNT WHERE account_number=?");
			
			preparedStatement.setLong(1, accountNumber);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				accNumber = resultSet.getLong(1);
				balance = resultSet.getLong(2);
				pinCode = resultSet.getShort(3);
				userName = resultSet.getString(4);
				account = new Account(balance, pinCode, userName);
				account.setAccountNumber(accountNumber);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return account;
	}
	
	public int updateBalance(long balance,long accNumber)
	{
		int updated = 0;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update account set balance=? where account_number=?");
			preparedStatement.setLong(1, balance);
			preparedStatement.setLong(2, accNumber);
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return updated;
	}

}
