
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {

		try {
			ServerSocket echoServer = new ServerSocket(7200);
			Socket server = echoServer.accept();
			System.out.println("Server Started .....");
			System.out.println("Waiting for the Client");

			System.out.println("Client Paired Successfully!");

			server.close();
			echoServer.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
