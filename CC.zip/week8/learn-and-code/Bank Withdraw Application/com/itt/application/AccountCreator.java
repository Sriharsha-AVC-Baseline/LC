package com.itt.application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Optional;

import com.itt.db.DBOperator;
import com.itt.pojo.Account;

public class AccountCreator {

	private BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	private DBOperator dbOperator = new DBOperator();

	public Account createAccount()

	{
		Account account = scanDetails();

		dbOperator.addAccount(account);

		return account;
	}

	private Account scanDetails() {

		Account newAccount = null;

		try {
			System.out.print("Enter the Account Holder name : ");
			String name = bufferedReader.readLine();
			System.out.print("Enter the initial Deposit amount in Rs : ");
			long deposit = scanDeposit();
			System.out.println("Enter an ATM Pin");
			short atmPin = scanPin();
			newAccount = new Account(deposit, atmPin, name);
		} catch (Exception e) {
			System.out.println("Some thing went wrong");
		}

		Optional<Account> account = Optional.ofNullable(newAccount);

		if (account.isEmpty()) {
			System.out.println("Please Enter the Details again");
			scanDetails();
		}
		return account.get();
	}

	private short scanPin() {
		boolean validPin = false;
		short atmPin = (short) 0;
		short atmPinA = (short) 0;
		while (!validPin) {
			try {
				atmPin = Short.parseShort(bufferedReader.readLine());
				System.out.println("Confirm your Pin");
				atmPinA = Short.parseShort(bufferedReader.readLine());
				if (atmPin == atmPinA) {
					validPin = true;
				} else {
					System.out.println("Enter Valid pin");
				}
			} catch (NumberFormatException | IOException e) {
				System.out.println("Enter Valid Pin");
			}
		}
		return atmPin;
	}

	private long scanDeposit() {
		boolean validDeposit = false;
		long deposit = 0l;
		while (!validDeposit) {
			try {
				deposit = Long.parseLong(bufferedReader.readLine());
				validDeposit = true;
			} catch (NumberFormatException | IOException e) {
				System.out.println("Enter Valid amount");
			}
		}
		return deposit;
	}
}