package com.itt.application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.UnknownHostException;

import com.itt.components.ServerConnector;
import com.itt.exceptions.ServerErrorException;
import com.itt.pojo.Account;

public class BankApplication {

	BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	Withdraw withdraw = new Withdraw();
	AccountCreator creator = new AccountCreator();
	ServerConnector connector = new ServerConnector();

	public void startApp() {

		System.out.println("Welcome to Bank");
		byte choice = 0;
		
		try {
			connectServer();
			System.out.println("Server Connected Successfully!!!\n");
		} catch (IOException e) {
			System.out.println("Server Busy!!! Try After Some Time");
			return;
		}
		

		while (choice != 2) {
			System.out.println("Enter your choice\n1.Create Account\n2.Withdraw\nAny other key to close");
			try {
				choice = Byte.parseByte(bufferedReader.readLine());
			} catch (NumberFormatException | IOException e) {
				// TODO Auto-generated catch block
				choice = 2;
			}

			if (choice == 1) {
				Account account = creator.createAccount();
				System.out.println("Your Account has been Created Successfully, Note the account Number");
				System.out.println("Account Number : " + account.getAccountNumber());
			}

			else if (choice == 2) {

				withdraw.WithdrawAmmount();

			}
			if (choice == 2) {
				System.out.println("Thank you, Visit Again");
				break;
			}

		}

	}
	
	private void connectServer() throws UnknownHostException, IOException {
		connector.connectServer();
	}

}
