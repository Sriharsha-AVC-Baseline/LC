package com.itt.application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.itt.components.ServerConnector;
import com.itt.db.DBOperator;
import com.itt.exceptions.InsufficientFundException;
import com.itt.exceptions.InvalidPinCodeException;
import com.itt.exceptions.ServerErrorException;
import com.itt.pojo.Account;

public class Withdraw {

	private Account account;
	private ServerConnector serverConnector = new ServerConnector();
	private DBOperator dbOperator = new DBOperator();
	BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));


	public void WithdrawAmmount()  {
		long withdrawAmmount = 0;
		long accountNumber = getAccountNumber();
		boolean isValidPinCode = false;
		boolean hasSufficientBalance = true;

		account = dbOperator.getDetails(accountNumber);
		
		System.out.println("Enter the amount you want to withdraw");
		try {
			withdrawAmmount = Long.parseLong(bufferedReader.readLine());
		} catch (IOException | NumberFormatException e) {
			System.out.println("Enter Valid Amount");
			WithdrawAmmount();
			return;
		}
		try {
			checkBalance(withdrawAmmount);
		} catch (InsufficientFundException e) {
			hasSufficientBalance = false;
			System.out.println(e.getMessage());
			return;
		}
		isValidPinCode = checkPinCode();

		if (isValidPinCode && hasSufficientBalance) {

			account.setAmount(account.getAmount() - withdrawAmmount);
			System.out.println("Your balance is : " + account.getAmount());
			dbOperator.updateBalance(account.getAmount(), accountNumber);
		}

	}

	private long getAccountNumber() {
		long accNumner = 0;
		try {
			 System.out.println("Enter Account Number");
			 accNumner = Long.parseLong(bufferedReader.readLine());
		} catch (NumberFormatException | IOException e) {
			System.out.println("Enter Valid Account Number");
			accNumner = getAccountNumber();
		}
		return accNumner;
	}



	private void checkBalance(long withdrawAmmount) throws InsufficientFundException {
		long balance = account.getAmount();
		if (balance < 100l || withdrawAmmount > balance) {

			throw new InsufficientFundException();
		}
	}

	private boolean checkPinCode() {
		boolean isValidPincode = false;
		byte numberOfTries = 3;
		short pinCode;
		System.out.println("Enter Pin code");
		while (numberOfTries > 0) {
			try {
				numberOfTries--;
				pinCode = Short.parseShort(bufferedReader.readLine());
				if (pinCode == account.getPinCode()) {
					return true;
				} else {
					throw new InvalidPinCodeException();
				}

			} catch (NumberFormatException | IOException e) {
				System.out.println("Enter Proper number ");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			System.out.println("Tries left = " + numberOfTries);
		}
		return isValidPincode;
	}

}
