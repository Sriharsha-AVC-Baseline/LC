package com.itt.exceptions;

public class ServerErrorException extends Exception {
	
	public ServerErrorException() {
		super("Server Down! please try after some Time");
	}

}
