package com.itt.exceptions;

public class InsufficientFundException extends Exception {

	public InsufficientFundException() {
		
		
		super("You Don't have suffient funds in your account");
	}
	
}
