package com.itt.exceptions;

public class InvalidPinCodeException extends Exception {
	public InvalidPinCodeException() {
		super("Pin Code Incorrect");
	}
}
