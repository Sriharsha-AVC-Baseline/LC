package com.itt;

import com.itt.application.BankApplication;

public class ClientApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BankApplication bankApplication = new BankApplication();
		bankApplication.startApp();

	}

}
