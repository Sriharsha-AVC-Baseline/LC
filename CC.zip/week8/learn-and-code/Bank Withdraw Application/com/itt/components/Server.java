package com.itt.components;

public class Server {

	
	public boolean ifServerRunning()
	{
		boolean isRunning = false;
		int number = (int) (100 * (Math.random()));
		
		if(number > 10)
		{
			isRunning = true;
		}
		return isRunning;
	}
}
