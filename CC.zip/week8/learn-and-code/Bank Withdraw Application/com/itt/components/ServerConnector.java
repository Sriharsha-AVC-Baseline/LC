package com.itt.components;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ServerConnector {

	
	public void connectServer() throws UnknownHostException, IOException
	{
			
				Socket socket = new Socket(InetAddress.getLocalHost(), 7200);
			
			
			
		
	}
}
