package com.itt.pojo;

public class Account {
	private long amount;
	private short pinCode;
	private long accountNumber;
	private String AccountHolderName;

	public Account(long amount, short pinCode, String name) {
		this.accountNumber = this.hashCode();
		this.amount = amount;
		this.pinCode = pinCode;
		setAccountHolderName(name);
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public short getPinCode() {
		return pinCode;
	}

	public void setPinCode(short pinCode) {
		this.pinCode = pinCode;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public long getAccountNumber() {
		return this.accountNumber;
	}

	public String getAccountHolderName() {
		return AccountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		AccountHolderName = accountHolderName;
	}

}
