package com.itt.application;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) {

		GeocodingCoordinateFetcher geocodingCoordinateFetcher = new GeocodingCoordinateFetcher();
		Coordinates coordinates = null;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

		try {
			// "Silk Board Bangalore India"
			String address = bufferedReader.readLine();
			coordinates = geocodingCoordinateFetcher.getCoordinate(address);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println(coordinates);
	}

}
