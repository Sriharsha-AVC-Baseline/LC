package com.itt.application;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import com.itt.Url.StringRefactorer;
import com.itt.Url.UrlFetcher;
import com.itt.exceptions.InvalidAddressException;
import com.itt.json.ResponseFilter;

public class GeocodingCoordinateFetcher {

	public Coordinates getCoordinate(String Address) throws InvalidAddressException {
		
		HttpRequest request = generateHttpRequest(Address);

		HttpResponse<String> response = null;

		try {
			response = getResponse(request);
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}

		Coordinates cordinate = getCordinates(response);

		return cordinate;

	}
	
	private HttpRequest generateHttpRequest(String Address) {
		
		UrlFetcher urlFetcher = new UrlFetcher();
		HttpRequest request = HttpRequest.newBuilder(urlFetcher.generateUri(StringRefactorer.refactorString(Address))).GET().build();
		return request;
	}
	
	private HttpResponse<String> getResponse(HttpRequest request) throws IOException, InterruptedException {
		
		HttpClient client = HttpClient.newHttpClient();
		HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
		return response;
	}

	private Coordinates getCordinates(HttpResponse<String> response) throws InvalidAddressException {

		String jsonOutput = response.body();
		Coordinates coodrinates = new ResponseFilter().filterResponse(jsonOutput);
		return coodrinates;

	}
	

}
