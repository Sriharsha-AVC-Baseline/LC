package com.itt.Url;

public class StringRefactorer {

		public static String refactorString(String location) {
			return location.replaceAll("\\s", "%20");
		}
	
}
