package com.itt.Url;

public enum URI {
	
	GENERAL_URI("https://maps.googleapis.com/maps/api/geocode/json");
	
	private String url;
	
	URI(String url)
	{
		this.url = url;
	}
	
	public String getUrl() {
		return url;
	}

}
