package com.itt.Url;

import java.net.URI;


public class UrlFetcher {

	public URI generateUri(String Address)
	{
		String url = com.itt.Url.URI.GENERAL_URI.getUrl() +"?address=" + Address + "&key="+ new ApiKeyFetcher().getApiKey();
		
		return URI.create(url);
	}
	
	public URI generateUriWithDummyAPI(String Address)
	{
		String url = com.itt.Url.URI.GENERAL_URI.getUrl() +"?address=" + Address + "&key=Dummy";
		
		return URI.create(url);
	}
	
	private class ApiKeyFetcher {
		
		private String apiKey;
		
		private ApiKeyFetcher() {
			apiKey = System.getenv("apiKey");
		}
		
		String getApiKey()
		{
			return apiKey;
		}

	}
	
	
}
