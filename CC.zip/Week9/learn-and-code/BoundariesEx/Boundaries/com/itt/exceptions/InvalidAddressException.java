package com.itt.exceptions;

public class InvalidAddressException extends Exception {
	
	public InvalidAddressException() {
		super("Invalid Address Enter Address with City and Country name");
	}

}
