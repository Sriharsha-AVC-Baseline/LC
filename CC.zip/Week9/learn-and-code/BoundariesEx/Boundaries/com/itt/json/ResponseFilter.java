package com.itt.json;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.itt.application.Coordinates;
import com.itt.exceptions.InvalidAddressException;

public class ResponseFilter {

	public Coordinates filterResponse(String jsonOutput) throws InvalidAddressException {
		JSONObject jsonObject = (JSONObject) (JSONValue.parse(jsonOutput));
		JSONArray result = (JSONArray) (jsonObject.get("results"));

		if (result.isEmpty()) {
			throw new InvalidAddressException();
		}

		JSONObject geometry = JSONObject.class.cast(JSONObject.class.cast(result.get(0)).get("geometry"));

		JSONObject location = (JSONObject) geometry.get("location");
		location = (JSONObject) geometry.get("location");

		Coordinates coodrinates = extractCordinates(location);

		return coodrinates;

	}

	private Coordinates extractCordinates(JSONObject location) {

		Coordinates coordinates = new Coordinates();
		coordinates.setLatitude(Double.parseDouble(location.get("lat").toString()));
		coordinates.setLongitude(Double.parseDouble(location.get("lng").toString()));
		return coordinates;
	}

}
