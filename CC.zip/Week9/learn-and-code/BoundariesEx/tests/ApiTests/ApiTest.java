package ApiTests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.itt.Url.StringRefactorer;
import com.itt.Url.UrlFetcher;

class ApiTest {

	UrlFetcher fetcher;
	HttpResponse<String> response;
	private static final boolean SET_DUMMY_URL = true; 
	private static final boolean SET_REAL_URL = false; 

	void getResponse(String address,boolean setDummy) {
		HttpClient client = HttpClient.newHttpClient();

		HttpRequest request = null;
		if(!setDummy)
		{
			 request = HttpRequest.newBuilder(fetcher.generateUri(StringRefactorer.refactorString(address)))
				.GET().build();
		}
		else
		{
			request = HttpRequest.newBuilder(fetcher.generateUriWithDummyAPI(StringRefactorer.refactorString(address)))
					.GET().build();
		}

		try {
			HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

			System.out.println(response.body());

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	@DisplayName("Valid Address")
	void test1() {
		fetcher = new UrlFetcher();
		getResponse("Silk Board Bangalore India",SET_REAL_URL);
	}

	@Test
	@DisplayName("Invalid Address")
	void test2() {
		fetcher = new UrlFetcher();
		getResponse("Skill",SET_REAL_URL);
		
	}
	
	@Test
	@DisplayName("Dummy url")
	void test3() {
		fetcher = new UrlFetcher();
		getResponse("Skill",SET_DUMMY_URL);
		
	}

}
