import java.util.List;


// This class represents the fields of desired outputs
public class FilteredOutput {
	
	private String title;
	
	private String name;
	
	private String description;
	
	private long numberOfPosts;
	
	private List<String> photoUrls;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getNumberOfPosts() {
		return numberOfPosts;
	}

	public void setNumberOfPosts(long numberOfPosts) {
		this.numberOfPosts = numberOfPosts;
	}

	public List<String> getPhotoUrls() {
		return photoUrls;
	}

	public void setPhotoUrls(List<String> photoUrls) {
		this.photoUrls = photoUrls;
	}
	
	

}
