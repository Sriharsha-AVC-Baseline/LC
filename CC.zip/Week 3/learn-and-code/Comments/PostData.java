
// This is a class containing the basic details which is used to request the blog post
public class PostData {

private String blogName;
	
	private int	startPostNumber;
	
	private int endPostNumber;
	
	private int totalPosts;

	public String getBlogName() {
		return blogName;
	}

	public void setBlogName(String blogName) {
		this.blogName = blogName;
	}

	public int getStartPostNumber() {
		return startPostNumber;
	}

	public void setStartPostNumber(int startPostNumber) {
		this.startPostNumber = startPostNumber;
	}

	public int getEndPostNumber() {
		return endPostNumber;
	}

	public void setEndPostNumber(int endPostNumber) {
		this.endPostNumber = endPostNumber;
	}

	public int getTotalPosts() {
		return totalPosts;
	}

	public void setTotalPosts(int totalPosts) {
		this.totalPosts = totalPosts;
	}
	
}
