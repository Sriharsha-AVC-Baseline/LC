import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import com.mysql.cj.xdevapi.Client;
import com.mysql.cj.xdevapi.JsonArray;


// This class mainly deals with the JSON Operations
public class JsonOperations {
	
	// This will parse the Java json Object using RAW json Response string
	public static JSONObject getJsonObject(String jsonResopnse) throws ParseException
	{
		JSONParser jsonParser = new JSONParser();
		
		JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonResopnse);
		
		return jsonObject;
	}
	
	
	// This will return the final Desired result object to main class
	public static FilteredOutput getFilteredOutput(String jsonResponse) throws ParseException
	{
		
		JSONObject jsonObject = getJsonObject(jsonResponse);
		
		FilteredOutput filteredOutput = extractDetails(jsonObject);
		
		return filteredOutput;
		
	}
	
	// This method will extract all the desired fields required for output
	public static FilteredOutput extractDetails(JSONObject jsonObject)
	{
		FilteredOutput filteredOutput = new FilteredOutput();
		
		Map jsonMap = (Map) jsonObject.get("tumblelog"); 
		
		JSONArray jsonArray = (JSONArray)jsonObject.get("posts");
		
		filteredOutput.setTitle(getTitle(jsonMap));
		filteredOutput.setName(getName(jsonMap));
		filteredOutput.setDescription(getDescription(jsonMap));
		filteredOutput.setNumberOfPosts(getTotalPost(jsonObject));
		filteredOutput.setPhotoUrls(getPhotoUrls(jsonArray));
		
		return filteredOutput;
	}
	
	// This will return a list of photo urls of the posts
	public static List<String> getPhotoUrls(JSONArray jsonArray)
	{
		List<String> photoUrls = new ArrayList<String>();

		Iterator posts = jsonArray.iterator();
		
		while(posts.hasNext())
		{
			JSONObject jsonPhotoObject = (JSONObject)posts.next();
			photoUrls.add((String)jsonPhotoObject.get("photo-url-1280"));
		}
		
		return photoUrls;
	}
	
	
	/*
	 *  The following methods will extract the specific information
	 * 
	 */
	
	public static String getTitle(Map jsonMap)
	{
		return (String)jsonMap.get("title");
	}
	
	public static String getName(Map jsonMap)
	{
		return (String)jsonMap.get("name");
	}
	
	public static long getTotalPost(JSONObject jsonObject)
	{
		return (long)jsonObject.get("posts-total");
	}
	
	public static String getDescription(Map jsonMap)
	{
		return (String)jsonMap.get("description");
	}
	
}
