import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import com.mysql.cj.xdevapi.Client;
import com.mysql.cj.xdevapi.JsonArray;



/**
 * 
 *  This program is intended to fetch the details of the blog post of Tumbler
 * 	
 * 	It will fetch Title, Name, Description, Number of posts on a blog
 * 
 * 	It will also return the urls of Highest quality photos of a given number of posts
 * 
 *  Java is used to consume Tumbler API
 *  
 */


public class Main {
	
	
	
	// This method will ask Blog Details and will return BlogPost details
	public static PostData getPostDetails() throws IOException
	{
		
		PostData postData = new PostData();
		
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the blog name: ");
		
		postData.setBlogName(bufferedReader.readLine());
		
		System.out.println("Enter the Range :");
		
		String rangeAsRawString = bufferedReader.readLine();
		
		postData = parseRange(rangeAsRawString, postData);
		
		postData.setTotalPosts(postData.getEndPostNumber() - postData.getStartPostNumber());
		
		return postData;
		
	}
	
	
	// This method will filter the post range that is upper limit and lower limit of the post in out of total posts
	public static PostData parseRange(String rangeAsRawString,PostData postData)
	{
		String[] range = rangeAsRawString.split("-");
		
		postData.setStartPostNumber(Integer.parseInt(range[0]));
		
		postData.setEndPostNumber(Integer.parseInt(range[1]));
		
		return postData;
	}
	
	// This method will generate the Request url based on the user's details
	public static String generateURI(PostData post)
	{
		String uri = "https://"+post.getBlogName()+".tumblr.com/api/read/json?type=photo&num="+post.getTotalPosts()+"&start="+post.getStartPostNumber();

		return uri;
	}
	
	
	// This will print the desired output of the response message given by the API
	public static void printResult(FilteredOutput filteredOutput)
	{
		System.out.println("Blog Title : "+filteredOutput.getTitle());
		System.out.println("Blog Name : "+filteredOutput.getName());
		System.out.println("Blog Description : "+filteredOutput.getDescription());
		System.out.println("Number of Posts : "+filteredOutput.getNumberOfPosts());
		System.out.println("Photo urls : ");
		filteredOutput.getPhotoUrls().stream().forEach(e->System.out.println(e));
	}
	

	public static void main(String[] args) throws IOException, InterruptedException, ParseException {
		// TODO Auto-generated method stub
		
		
		PostData postData = getPostDetails();
		
		String uri = generateURI(postData);
		
		
		
		HttpRequest httpRequest = FetchOperations.buildHttpRequest(uri);
		
		HttpResponse<String> httpResponse = FetchOperations.getResponseFromTheHttpRequest(httpRequest);
		
		String jsonResponse = FetchOperations.getJsonResponse(httpResponse);
		
		FilteredOutput output = JsonOperations.getFilteredOutput(jsonResponse);
		
		printResult(output);
		
		
	}

}
