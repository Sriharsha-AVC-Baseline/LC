import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

// This class is responsible for requesting the API and getting the response
public class FetchOperations {

	// This method will build the Http Request object for the URI
	public static HttpRequest buildHttpRequest(String uri)
	{
		return  HttpRequest.newBuilder().GET().uri(URI.create(uri)).build();
	}
	
	// This method will get the HttpResponse using the HttpRequest Object
	public static HttpResponse<String> getResponseFromTheHttpRequest(HttpRequest httpRequest) throws IOException, InterruptedException
	{
		HttpClient client = HttpClient.newBuilder().build();
		
		HttpResponse<String> httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
		
		return httpResponse;
	}
	
	// This will fetch the jsonResponse from the response object
	public static String getJsonResponse(HttpResponse<String> httpResponse)
	{
		String responseJson = httpResponse.body();
		
		String jsonResponse = filterJsonResponse(responseJson);
		
		return jsonResponse;
	}
	
	// This will filter the syntax errors inside Json response message 
	public static String filterJsonResponse(String responseJson)
	{
		int startIndex = responseJson.indexOf("{");
		
		String jsonResponse = responseJson.substring(startIndex, responseJson.length()-2);
		
		return jsonResponse;
	}
}
